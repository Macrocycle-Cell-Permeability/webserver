<!doctype html>
<html class="no-js" lang="en-US">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title>Download jQuery | jQuery</title>

	<meta name="author" content="OpenJS Foundation - openjsf.org">
	<meta name="description" content="jQuery: The Write Less, Do More, JavaScript Library">
	<meta name="viewport" content="width=device-width">

	<link rel="shortcut icon" href="https://jquery.com/wp-content/themes/jquery.com/i/favicon.ico">
	<link rel="stylesheet" href="https://jquery.com/wp-content/themes/jquery/lib/typesense-minibar/typesense-minibar.css">
	<link rel="stylesheet" href="https://jquery.com/wp-content/themes/jquery/css/base.css?v=15">
	<link rel="stylesheet" href="https://jquery.com/wp-content/themes/jquery.com/style.css?v=8">

	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<script src="https://jquery.com/wp-content/themes/jquery/js/main.js"></script>
<meta name='robots' content='max-image-preview:large' />
<link rel="https://api.w.org/" href="https://jquery.com/wp-json/" /><link rel="alternate" type="application/json" href="https://jquery.com/wp-json/wp/v2/pages/6" /><meta name="generator" content="WordPress 6.5.2" />
<link rel="canonical" href="https://jquery.com/download/" />
<link rel="alternate" type="application/json+oembed" href="https://jquery.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjquery.com%2Fdownload%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://jquery.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjquery.com%2Fdownload%2F&#038;format=xml" />
<link rel="me" href="https://social.lfx.dev/@jquery">
</head>
<body class="jquery page-template-default page page-id-6 page-slug-download single-author singular">

<header>
	<section id="global-nav">
		<nav>
			<div class="constrain">
				<ul class="projects">
					<li class="project jquery"><a href="https://jquery.com/" title="jQuery">jQuery</a></li>
					<li class="project jquery-ui"><a href="https://jqueryui.com/" title="jQuery UI">jQuery UI</a></li>
					<li class="project jquery-mobile"><a href="https://jquerymobile.com/" title="jQuery Mobile">jQuery Mobile</a></li>
					<li class="project sizzlejs"><a href="https://sizzlejs.com/" title="Sizzle">Sizzle</a></li>
					<li class="project qunitjs"><a href="https://qunitjs.com/" title="QUnit">QUnit</a></li>
				</ul>
				<ul class="links">
					<li><a href="https://plugins.jquery.com/">Plugins</a></li>
					<li class="dropdown"><a href="https://contribute.jquery.org/">Contribute</a>
						<ul>
							<li><a href="https://cla.openjsf.org/">CLA</a></li>
							<li><a href="https://contribute.jquery.org/style-guide/">Style Guides</a></li>
							<li><a href="https://contribute.jquery.org/triage/">Bug Triage</a></li>
							<li><a href="https://contribute.jquery.org/code/">Code</a></li>
							<li><a href="https://contribute.jquery.org/documentation/">Documentation</a></li>
							<li><a href="https://contribute.jquery.org/web-sites/">Web Sites</a></li>
						</ul>
					</li>
					<li class="dropdown"><a href="https://events.jquery.org/">Events</a>
						<ul class="wide">
						</ul>
					</li>
					<li class="dropdown"><a href="https://jquery.com/support/">Support</a>
						<ul>
							<li><a href="https://learn.jquery.com/">Learning Center</a></li>
							<li><a href="https://jquery.com/support/">Chat</a></li>
							<li><a href="https://stackoverflow.com/tags/jquery/info">Stack Overflow</a></li>
							<li><a href="https://contribute.jquery.org/bug-reports/">Report a bug</a></li>
						</ul>
					</li>
					<li class="dropdown"><a href="https://openjsf.org/">OpenJS Foundation</a>
						<ul>
							<li><a href="https://openjsf.org/about/join/">Join</a></li>
							<li><a href="https://openjsf.org/about/members/">Members</a></li>
							<li><a href="https://jquery.com/team">jQuery Team</a></li>
							<li><a href="https://openjsf.org/about/governance/">Governance</a></li>
							<li><a href="https://code-of-conduct.openjsf.org/">Conduct</a></li>
							<li><a href="https://openjsf.org/about/project-funding-opportunities/">Donate</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</nav>
	</section>
</header>

<div id="container">
	<div id="logo-events" class="constrain clearfix">
		<h2 class="logo"><a href="/" title="jQuery">jQuery</a></h2>

		<aside id="broadcast"></aside>
	</div>

	<nav id="main" class="constrain clearfix">
		<div class="menu-top-container">
	<button hidden id="menu-trigger" class="button menu-trigger" aria-expanded="false" aria-haspopup="menu">Navigation</button>
	<ul id="menu-top" class="menu" role="menu" aria-labelledby="menu-trigger">
<li class="menu-item current"><a href="https://jquery.com/download/">Download</a></li>
<li class="menu-item"><a href="https://api.jquery.com/">API Documentation</a></li>
<li class="menu-item"><a href="https://blog.jquery.com/">Blog</a></li>
<li class="menu-item"><a href="https://plugins.jquery.com/">Plugins</a></li>
<li class="menu-item"><a href="https://jquery.com/browser-support/">Browser Support</a></li>
	</ul>
</div>

		<form role="search" class="searchform tsmb-form" action="https://jquery.com/" method="get"	data-origin="https://typesense.jquery.com"
	data-collection="jquery_com"
	data-key="Zh8mMgohXECel9wjPwqT7lekLSG3OCgz"
	data-foot="true" data-group="true"
>
	<input type="search" name="s" aria-label="Search jQuery" value="" placeholder="Search" autocomplete="off">
	<button type="submit" class="visuallyhidden"></button>
</form>
	</nav>

	<div id="content-wrapper" class="clearfix row">


<div class="content-full twelve columns">
	<div id="content">
				<h1 class="entry-title">Download jQuery</h1>
		<hr>
		
		
<h2 class="toc-linked" id="latest-version"><a href="#latest-version" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> Latest version</h2><p>To locally download these files, right-click the link and select "Save as..." from the menu.</p>
<p>Download the compressed, production version:</p>
<p><a class="button db" href="https://code.jquery.com/jquery-3.7.1.min.js">Download jQuery 3.7.1</a></p>
<ul>
<li><a href="https://code.jquery.com/jquery-3.7.1.js">Download the uncompressed development version of jQuery 3.7.1</a></li>
<li><a href="https://code.jquery.com/jquery-3.7.1.min.map">Download the map file for jQuery 3.7.1</a></li>
<li><a href="https://blog.jquery.com/2023/08/28/jquery-3-7-1-released-reliable-table-row-dimensions/">jQuery 3.7.1 blog post with release notes</a></li>
</ul>
<p>The slim build is a smaller version, that excludes the <a href="https://api.jquery.com/category/ajax/">ajax</a> and <a href="https://api.jquery.com/category/effects/">effects</a> modules:</p>
<ul>
<li><a href="https://code.jquery.com/jquery-3.7.1.slim.min.js">Download jQuery 3.7.1 slim build</a></li>
<li><a href="https://code.jquery.com/jquery-3.7.1.slim.js">Download the uncompressed development version of the jQuery 3.7.1 slim build</a></li>
<li><a href="https://code.jquery.com/jquery-3.7.1.slim.min.map">Download the map for the jQuery 3.7.1 slim build</a></li>
</ul>
<p>The uncompressed version is best used during development or debugging; the compressed file saves bandwidth and improves performance in production. You can download the <a href="https://www.html5rocks.com/en/tutorials/developertools/sourcemaps/">source map</a> file to help with debugging the compressed production version. The source map is <em>not</em> required for end-users to run jQuery; it is a tool to help improve a developer's debugging experience. As of jQuery 1.11/2.1, we <a href="https://blog.jquery.com/2014/01/24/jquery-1-11-and-2-1-released/">no longer link source maps</a> to compressed releases by default.</p>
<p>Browse the jQuery CDN at <strong><a href="https://releases.jquery.com">releases.jquery.com</a></strong> for a full list of assets, including older and historical versions.</p>
<h3 class="toc-linked" id="upgrade"><a href="#upgrade" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> Upgrade</h3><p>For help when upgrading jQuery, read the <a href="/upgrade-guide/">upgrade guide</a>.
We also recommend using the <a href="https://github.com/jquery/jquery-migrate">jQuery Migrate plugin</a></p>
<h3 class="toc-linked" id="jquery-migrate-plugin"><a href="#jquery-migrate-plugin" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> jQuery Migrate Plugin</h3><p>The <a href="https://github.com/jquery/jquery-migrate/#readme">jQuery Migrate plugin</a> simplifies upgrading from older versions of jQuery. The plugin restores deprecated features and behaviors so that older code will still run properly on newer versions of jQuery.</p>
<p>When upgrading from a pre-1.9 jQuery version to jQuery 1.9 or upto jQuery 3.0, first use jQuery Migrate 1.x:</p>
<ul>
<li><a href="https://code.jquery.com/jquery-migrate-1.4.1.min.js">Download jQuery Migrate 1.4.1</a> (compressed production version)</li>
<li><a href="https://code.jquery.com/jquery-migrate-1.4.1.js">Download the uncompressed, development jQuery Migrate 1.4.1</a></li>
</ul>
<p>When migrating from jQuery 3.x to a later jQuery 3.x version, use jQuery Migrate 3.x instead:</p>
<ul>
<li><a href="https://code.jquery.com/jquery-migrate-3.4.0.min.js">Download jQuery Migrate 3.4.0</a> (compressed production version)</li>
<li><a href="https://code.jquery.com/jquery-migrate-3.4.0.js">Download the uncompressed, development jQuery Migrate 3.4.0</a></li>
</ul>
<p>Use the <em>compressed production</em> version to simply restore compatibility issues without changing any application code.</p>
<p>Use the <em>uncompressed development</em> version to additionally diagnose and help migrate compatibility issues, through helpful warnings on the console that identify how to transition your application code.</p>
<h2 class="toc-linked" id="downloading-jquery-using-npm-or-yarn"><a href="#downloading-jquery-using-npm-or-yarn" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> Downloading jQuery using npm or Yarn</h2><p>jQuery is published on <a href="https://www.npmjs.com/">npm</a> under the <a href="https://www.npmjs.com/package/jquery">jquery package</a>. You can install the latest version of jQuery with the npm CLI:</p>
<div class="syntaxhighlighter javascript">
	<table>
		<tbody>
			<tr>
				
				<td class="gutter">
					
						<div class="line n1">1</div>
					
				</td>
				
				<td class="code">
					<pre><div class="container"><div class="line"><code>npm install jquery</code></div></div></pre>
				</td>
			</tr>
		</tbody>
	</table>
</div>

<p>As an alternative you can use the <a href="https://github.com/yarnpkg/yarn">Yarn CLI</a>:</p>
<div class="syntaxhighlighter javascript">
	<table>
		<tbody>
			<tr>
				
				<td class="gutter">
					
						<div class="line n1">1</div>
					
				</td>
				
				<td class="code">
					<pre><div class="container"><div class="line"><code>yarn add jquery</code></div></div></pre>
				</td>
			</tr>
		</tbody>
	</table>
</div>

<p>This will install jQuery in the <code>node_modules</code> directory. Within <code>node_modules/jquery/dist/</code> you will find an uncompressed release, a compressed release, and a map file.</p>
<h2 class="toc-linked" id="jquery-pre-release-builds"><a href="#jquery-pre-release-builds" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> jQuery Pre-Release Builds</h2><p>The jQuery team is constantly working to improve the code. Each commit to the Github repo generates a work-in-progress version of the code that we update on the jQuery CDN. We recommend they be used to determine whether a bug has already been fixed when reporting bugs against released versions, or to see if new bugs have been introduced.</p>
<p><em>These versions are sometimes unstable and never suitable for production sites.</em></p>
<p><a href="https://releases.jquery.com/jquery/">Browse Git builds of jQuery</a></p>
<h2 class="toc-linked" id="jquery-cdn"><a href="#jquery-cdn" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> <a href="https://releases.jquery.com">jQuery CDN</a></h2><p>To use the jQuery CDN, reference the file in the script tag directly from the jQuery CDN domain. You can get the complete script tag, including Subresource Integrity attribute, by visiting <a href="https://releases.jquery.com">https://releases.jquery.com</a> and clicking on the version of the file that you want to use. Copy and paste that tag into your HTML file.</p>
<p>The jQuery CDN supports <a href="https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity">Subresource Integrity</a> (SRI) (<a href="https://www.w3.org/TR/SRI/">specification</a>) which allows the browser to verify that the files being delivered have not been modified. Adding the new integrity attribute will ensure your application gains this security improvement in supporting browsers.</p>
<p>Starting with jQuery 1.9, <a href="https://blog.jquery.com/2013/01/09/jquery-1-9-rc1-and-migrate-rc1-released/#sourcemaps">sourcemap files</a> are available on the jQuery CDN. However, as of version 1.10.0/2.1.0 the compressed jQuery no longer includes the sourcemap comment in CDN copies because it requires the uncompressed file and sourcemap file to be placed at the same location as the compressed file. If you are maintaining local copies and can control the locations all three files, you can add the sourcemap comment to the compressed file for easier debugging.</p>
<p>To see all available files and versions, including older and historical versions, visit <a href="https://releases.jquery.com">https://releases.jquery.com</a></p>
<h3 class="toc-linked" id="other-cdns"><a href="#other-cdns" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> Other CDNs</h3><p>The following CDNs also host compressed and uncompressed versions of jQuery releases. Starting with jQuery 1.9 they may also host <a href="https://blog.jquery.com/2013/01/09/jquery-1-9-rc1-and-migrate-rc1-released/#sourcemaps">sourcemap files</a>; check the site's documentation.</p>
<p>Note that <strong>there may be delays between a jQuery release and its availability there</strong>. Please be patient, they receive the files at the same time the blog post is made public. Beta and release candidates are not hosted by these CDNs.</p>
<ul>
<li><a href="https://developers.google.com/speed/libraries#jquery">Google CDN</a></li>
<li><a href="https://learn.microsoft.com/en-us/aspnet/ajax/cdn/overview#jQuery_Releases_on_the_CDN_0">Microsoft CDN</a></li>
<li><a href="https://cdnjs.com/libraries/jquery/">CDNJS CDN</a></li>
<li><a href="https://www.jsdelivr.com/package/npm/jquery">jsDelivr CDN</a></li>
</ul>
<h2 class="toc-linked" id="about-the-code"><a href="#about-the-code" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> About the Code</h2><p><strong>jQuery is provided under the <a href="https://jquery.com/license/">MIT license</a>.</strong></p>
<p>The code is hosted and developed in the <a href="https://github.com/jquery/jquery">jQuery GitHub repository</a>. If you've spotted some areas of code that could be improved, feel free to <a href="https://contribute.jquery.org/bug-reports/">report a bug</a>. If you'd like to participate in developing jQuery, peruse our <a href="https://contribute.jquery.org">contributor site</a> for more information.</p>
<p>Feedback about a jQuery plugin should be directed to the plugin author, not the jQuery team.</p>
<hr>
<h2 class="toc-linked" id="past-releases"><a href="#past-releases" class="icon-link toc-link"><span class="visuallyhidden">link</span></a> Past Releases</h2><p>All past releases can be found on the <a href="https://releases.jquery.com">jQuery CDN</a>.</p>	</div>
</div>

	</div>
</div>

<footer class="clearfix simple">
	<div class="constrain">
		<div class="row">
			<div class="six columns centered">
				<h3><span>Books</span></h3>
				<ul class="books">
					<li>
						<a href="https://www.packtpub.com/web-development/learning-jquery-fourth-edition">
							<img src="https://jquery.com/wp-content/themes/jquery/content/books/learning-jquery-4th-ed.jpg" alt="Learning jQuery 4th Edition by Karl Swedberg and Jonathan Chaffer" width="92" height="114" loading="lazy">
							Learning jQuery Fourth Edition
							<cite>Karl Swedberg and Jonathan Chaffer</cite>
						</a>
					</li>
					<li>
						<a href="https://www.manning.com/books/jquery-in-action-third-edition">
							<img src="https://jquery.com/wp-content/themes/jquery/content/books/jquery-in-action.jpg" alt="jQuery in Action by Bear Bibeault, Yehuda Katz, and Aurelio De Rosa" width="92" height="114" loading="lazy">
							jQuery in Action
							<cite>Bear Bibeault, Yehuda Katz, and Aurelio De Rosa</cite>
						</a>
					</li>
					<li>
						<a href="https://www.syncfusion.com/ebooks/jquery">
							<img src="https://jquery.com/wp-content/themes/jquery/content/books/jquery-succinctly.jpg" alt="jQuery Succinctly by Cody Lindley" width="92" height="114" loading="lazy">
							jQuery Succinctly
							<cite>Cody Lindley</cite>
						</a>
					</li>
				</ul>
			</div>
		</div>

		
<div id="legal" class="legal">
	<ul class="footer-site-links">
			<li><a class="icon-pencil" href="https://learn.jquery.com/">Learning Center</a></li>
			<li><a class="icon-comments" href="https://jquery.com/support/">Chat</a></li>
			<li><a class="icon-twitter" href="https://twitter.com/jquery">Twitter</a></li>
			<li><a class="icon-github" href="https://github.com/jquery">GitHub</a></li>
	</ul>
	<p class="copyright">
		Copyright 2024 <a href="https://openjsf.org/">OpenJS Foundation</a> and jQuery contributors. All rights reserved. See <a href="https://jquery.com/license/">jQuery License</a> for more information. The <a href="https://openjsf.org/">OpenJS Foundation</a> has registered trademarks and uses trademarks. For a list of trademarks of the <a href="https://openjsf.org/">OpenJS Foundation</a>, please see our <a href="https://trademark-policy.openjsf.org/">Trademark Policy</a> and <a href="https://trademark-list.openjsf.org/">Trademark List</a>. Trademarks and logos not indicated on the <a href="https://trademark-list.openjsf.org/">list of OpenJS Foundation trademarks</a> are trademarks™ or registered® trademarks of their respective holders. Use of them does not imply any affiliation with or endorsement by them. OpenJS Foundation <a href="https://terms-of-use.openjsf.org/">Terms of Use</a>, <a href="https://privacy-policy.openjsf.org/">Privacy</a>, and <a href="https://www.linuxfoundation.org/cookies">Cookie</a> Policies also apply.
	</p>
	<p><a href="https://www.digitalocean.com" class="do-link">Web hosting by Digital Ocean</a> | <a href="https://www.fastly.com/">CDN by Fastly</a> | <a href="https://wordpress.org/" class="wp-link">Powered by WordPress</a></p>
</div>

	</div>
</footer>

<script defer src="https://jquery.com/wp-content/themes/jquery/lib/typesense-minibar/typesense-minibar.js"></script>
</body>
</html>
